
/*
 * oled.h
 *
 *  Created on: 2018��7��2��
 *      Author: shida
 */

#ifndef OLED_H_
#define OLED_H_

//#define unsigned   char u8;//�����޷�������  8λ
//#define unsigned short     int u16;//�����޷�������  16λ
//#define unsigned           int u32;//�����޷������� 32λ

#define OLED_SCLK_Clr() { P3OUT&=0XEF;  }//P3.4  CLLK  ���õ͵�ƽ
#define OLED_SCLK_Set() { P3OUT|=BIT4; }//���øߵ�ƽ

#define OLED_SDIN_Clr()  { P3OUT&=0XF7; }//P3.3  DIN
#define OLED_SDIN_Set() { P3OUT|=BIT3;}

#define OLED_RST_Clr() { P1OUT&=0XBF; }//P1.6  RES
#define OLED_RST_Set() { P1OUT|=BIT6;}

#define OLED_DC_Clr() { P6OUT&=0XBF; }//P6.6   DC
#define OLED_DC_Set() { P6OUT|=BIT6;}

#define OLED_CS_Clr()  { P3OUT&=0XFB; }//P3.2  CS
#define OLED_CS_Set()  { P3OUT|=BIT2 ;}

#define OLED_CMD  0	//д����
#define OLED_DATA 1	//д����
#define Max_Column	128
#define SIZE 16

void delay_ms(unsigned short     int ms);//��ʱ����
void OLED_WR_Byte( unsigned   char dat, unsigned   char cmd);
void OLED_Clear(void);
void OLED_Set_Pos(unsigned char x, unsigned char y);
unsigned  int oled_pow( unsigned   char m, unsigned   char n);
void OLED_ShowChar(unsigned   char x,unsigned   char y,unsigned   char chr);
void OLED_ShowString(unsigned   char x,unsigned   char y,unsigned   char *chr);
void OLED_ShowNum(unsigned   char x,unsigned   char y, unsigned   int num,unsigned   char len,unsigned   char size);
void  OLED_Init(void);




#endif /* OLED_H_ */
