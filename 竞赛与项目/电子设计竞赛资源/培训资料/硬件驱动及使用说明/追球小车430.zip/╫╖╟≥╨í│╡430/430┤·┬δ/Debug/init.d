# FIXED

init.obj: ../init.c
init.obj: C:/ti/ccsv6/ccs_base/msp430/include/msp430.h
init.obj: C:/ti/ccsv6/ccs_base/msp430/include/msp430f5529.h
init.obj: C:/ti/ccsv6/ccs_base/msp430/include/in430.h
init.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/intrinsics.h
init.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/intrinsics_legacy_undefs.h
init.obj: ../defin.h
init.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/stdint.h
init.obj: ../init.h

../init.c: 
C:/ti/ccsv6/ccs_base/msp430/include/msp430.h: 
C:/ti/ccsv6/ccs_base/msp430/include/msp430f5529.h: 
C:/ti/ccsv6/ccs_base/msp430/include/in430.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/intrinsics.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/intrinsics_legacy_undefs.h: 
../defin.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/stdint.h: 
../init.h: 
