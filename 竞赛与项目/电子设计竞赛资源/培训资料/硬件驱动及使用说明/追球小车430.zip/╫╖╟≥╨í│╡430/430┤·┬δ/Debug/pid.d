# FIXED

pid.obj: ../pid.c
pid.obj: ../defin.h
pid.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/stdint.h
pid.obj: ../pid.h

../pid.c: 
../defin.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/stdint.h: 
../pid.h: 
