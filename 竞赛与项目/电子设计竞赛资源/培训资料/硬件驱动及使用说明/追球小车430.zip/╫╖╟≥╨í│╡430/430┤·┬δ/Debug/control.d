# FIXED

control.obj: ../control.c
control.obj: ../control.h
control.obj: ../defin.h
control.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/stdint.h
control.obj: ../pid.h
control.obj: C:/ti/ccsv6/ccs_base/msp430/include/msp430.h
control.obj: C:/ti/ccsv6/ccs_base/msp430/include/msp430f5529.h
control.obj: C:/ti/ccsv6/ccs_base/msp430/include/in430.h
control.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/intrinsics.h
control.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/intrinsics_legacy_undefs.h
control.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/math.h
control.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/linkage.h
control.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/_defs.h
control.obj: ../init.h

../control.c: 
../control.h: 
../defin.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/stdint.h: 
../pid.h: 
C:/ti/ccsv6/ccs_base/msp430/include/msp430.h: 
C:/ti/ccsv6/ccs_base/msp430/include/msp430f5529.h: 
C:/ti/ccsv6/ccs_base/msp430/include/in430.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/intrinsics.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/intrinsics_legacy_undefs.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/math.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/linkage.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/_defs.h: 
../init.h: 
