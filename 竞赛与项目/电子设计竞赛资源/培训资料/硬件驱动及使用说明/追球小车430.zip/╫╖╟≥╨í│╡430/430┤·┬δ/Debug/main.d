# FIXED

main.obj: ../main.c
main.obj: ../oled.h
main.obj: C:/ti/ccsv6/ccs_base/msp430/include/msp430.h
main.obj: C:/ti/ccsv6/ccs_base/msp430/include/msp430f5529.h
main.obj: C:/ti/ccsv6/ccs_base/msp430/include/in430.h
main.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/intrinsics.h
main.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/intrinsics_legacy_undefs.h
main.obj: ../defin.h
main.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/stdint.h
main.obj: ../init.h
main.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/stdlib.h
main.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/linkage.h
main.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/stdio.h
main.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/stdarg.h
main.obj: ../control.h
main.obj: ../pid.h

../main.c: 
../oled.h: 
C:/ti/ccsv6/ccs_base/msp430/include/msp430.h: 
C:/ti/ccsv6/ccs_base/msp430/include/msp430f5529.h: 
C:/ti/ccsv6/ccs_base/msp430/include/in430.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/intrinsics.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/intrinsics_legacy_undefs.h: 
../defin.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/stdint.h: 
../init.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/stdlib.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/linkage.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/stdio.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/stdarg.h: 
../control.h: 
../pid.h: 
