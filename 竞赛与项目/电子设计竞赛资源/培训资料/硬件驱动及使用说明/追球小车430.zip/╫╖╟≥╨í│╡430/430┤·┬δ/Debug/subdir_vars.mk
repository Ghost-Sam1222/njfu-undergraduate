################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../lnk_msp430f5529.cmd 

C_SRCS += \
../control.c \
../init.c \
../main.c \
../oled.c \
../pid.c 

OBJS += \
./control.obj \
./init.obj \
./main.obj \
./oled.obj \
./pid.obj 

C_DEPS += \
./control.d \
./init.d \
./main.d \
./oled.d \
./pid.d 

C_DEPS__QUOTED += \
"control.d" \
"init.d" \
"main.d" \
"oled.d" \
"pid.d" 

OBJS__QUOTED += \
"control.obj" \
"init.obj" \
"main.obj" \
"oled.obj" \
"pid.obj" 

C_SRCS__QUOTED += \
"../control.c" \
"../init.c" \
"../main.c" \
"../oled.c" \
"../pid.c" 


