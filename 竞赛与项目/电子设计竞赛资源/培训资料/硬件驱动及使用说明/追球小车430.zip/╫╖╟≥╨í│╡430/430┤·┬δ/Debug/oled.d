# FIXED

oled.obj: ../oled.c
oled.obj: ../oled.h
oled.obj: C:/ti/ccsv6/ccs_base/msp430/include/msp430.h
oled.obj: C:/ti/ccsv6/ccs_base/msp430/include/msp430f5529.h
oled.obj: C:/ti/ccsv6/ccs_base/msp430/include/in430.h
oled.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/intrinsics.h
oled.obj: C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/intrinsics_legacy_undefs.h

../oled.c: 
../oled.h: 
C:/ti/ccsv6/ccs_base/msp430/include/msp430.h: 
C:/ti/ccsv6/ccs_base/msp430/include/msp430f5529.h: 
C:/ti/ccsv6/ccs_base/msp430/include/in430.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/intrinsics.h: 
C:/ti/ccsv6/tools/compiler/ti-cgt-msp430_15.12.1.LTS/include/intrinsics_legacy_undefs.h: 
