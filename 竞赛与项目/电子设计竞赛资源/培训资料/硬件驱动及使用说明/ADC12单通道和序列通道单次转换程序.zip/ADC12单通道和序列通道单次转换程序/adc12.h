#ifndef __ADC12
#define __ADC12
void Adc12Init();
void Adc12Open(unsigned char doit);
void AdcDo(unsigned int adr,unsigned char mod);
void SetTongDao(unsigned char tongdao,unsigned char eos,unsigned char mem,unsigned char verf,unsigned char inter);
void Adc12Go();
void AdcGet(unsigned int *padc);
#endif
