#ifndef __WENDU
#define __WENDU
unsigned int SuanHuaShi(unsigned int adresult);
unsigned int SuanSheShi(unsigned int adresult);
#endif