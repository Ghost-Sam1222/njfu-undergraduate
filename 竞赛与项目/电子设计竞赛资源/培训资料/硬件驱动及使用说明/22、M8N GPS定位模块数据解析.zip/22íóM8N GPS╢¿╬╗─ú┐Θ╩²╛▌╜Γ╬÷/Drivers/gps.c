#include "headfile.h"
#include "gpio.h"
#include "string.h"
#include "oledfont.h"
#include "oled.h"
#include "stdlib.h"
#include "SystickTime.h"
#include "quene.h"
#include "gps.h"


const unsigned long work_baud=38400;
pvt_gps gps_data;


uint8_t ubx_checksum(uint8_t *buf,uint8_t ck_a,uint8_t ck_b)
{
	uint8_t pass=0x00;
	uint8_t CK_A = 0, CK_B = 0;
	for(uint16_t i=0;i<96;i++)
	{
		CK_A = CK_A + buf[i];
		CK_B = CK_B + CK_A;
	}
	if(ck_a==CK_A&&ck_b==CK_B) pass=0x01;
	return pass;
}

extern ring_buff_t com4_rx_buf;

uint16_t check_itow_time=0;
void gps_data_prase(uint8_t *update_flag)
{
	static uint32_t check_itow;
	uint16_t valid_byte_start=0;
	//if(flymaple.gps_idle_flag==0) return;//ͨ���жϴ��ڿ��б�־���������Ƿ��������
	//flymaple.gps_idle_flag=0;
	check_itow=gps_data.gps.itow;
	if(com4_rx_buf.tail<=99)//0-99����λ���ڴ���
	{
		valid_byte_start=106;
	}
	else//100-199����λ���ڴ���
	{
		valid_byte_start=6;
	}	
	//ubx��У��
	if(ubx_checksum(&com4_rx_buf.ring_buff[valid_byte_start-4],
								   com4_rx_buf.ring_buff[valid_byte_start+92],
								   com4_rx_buf.ring_buff[valid_byte_start+93]))
	{
		memcpy(&gps_data.gps,&com4_rx_buf.ring_buff[valid_byte_start],92*sizeof(unsigned char));
		check_itow_time=gps_data.gps.itow-check_itow;
		if(check_itow_time==100) 
		{
			*update_flag=1;
			gps_data.update=1;
			gps_data.gps_rec_time_ms=100*1000/((float)(work_baud/10));//100���ֽ�*����һ���ֽڿ���
		}
	}
}
